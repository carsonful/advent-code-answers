import keys

moves = keys.movements
x = 0
y = 0
aim = 0 
for i in range(len(moves)):
    movement = moves[i].split()
    if movement[0] == 'forward':
        x = x + int(movement[1])
        multipl = aim * int(movement[1])
        y = y + multipl
    elif movement[0] == 'up':
        aim = aim - int(movement[1])
    elif movement[0] == 'down':
        aim = aim + int(movement[1])


print("this is y" + str(y))
print("this is x" + str(x))
print('this is aim' + str(aim))
print("this is x and y multiplied" + str(x * y))



